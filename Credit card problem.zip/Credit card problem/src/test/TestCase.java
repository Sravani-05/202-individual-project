package test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import main.Controller;
import model.CreditCard;
import main.View;

class TestCase {

	View view = new View();
    Controller controller = new Controller(view);
	
	@Test
	void testTheReadFile() {
	
		List<CreditCard> list = controller.readFileData("input_file.csv");
		assertEquals(list.size(), 13);
		
	}
	
	@Test
	void testInvalidCard() {
	
		CreditCard card = new CreditCard("59012345678901234567890", "10/24", "Lisa Claire");
		assertEquals(card.getCardNumber().length() > 19, true);
		
	}
	
	


}
