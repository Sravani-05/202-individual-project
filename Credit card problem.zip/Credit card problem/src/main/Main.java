package main;

import model.CreditCard;

import java.util.List;


public class Main {

    public static String inputFilePath = "input_file.csv";
    public static String inputJSONFilePath = "input_file.json";
    public static String inputXMLFilePath = "input_file.xml";

    public static void main(String[] args) {

    //instances
    View view = new View();
    Controller controller = new Controller(view);

    //testing if it works...
    List<CreditCard> list = controller.readFileData(inputFilePath); // to save into list
    //to read the file data...
    //controller.readFileData(inputFilePath);
    List<CreditCard> list2 = controller.readJSONLFile(inputJSONFilePath);
    List<CreditCard> list3 = controller.readXMLFileData(inputXMLFilePath); // to save into list

    }


}
