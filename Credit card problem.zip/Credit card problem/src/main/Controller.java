package main;


import model.*;

import org.json.simple.JSONArray;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.parser.*;
import main.View;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


public class Controller {

    final int CardLength = 19; // 19 digit
    private View view;

    public Controller(View view) {
        this.view = view;
    }


    boolean isNumberic(String string)
    {
        int count = 0;
        for (int i = 0; i < string.length(); i++) {
            if(Character.isDigit(string.charAt(i)))
            {
                count++;
            }else continue;
        }

        if(count == string.length())
        {
            return true;
        }

        return false;
    }


    //to read csv file
    public List<CreditCard> readFileData(String path)
    {

        List<CreditCard> list = new ArrayList<CreditCard>();
        List<CreditCard_> list2 = new ArrayList<>();

        try
        {

            File file = new File(path);
            Scanner scanner = new Scanner(file);
            System.out.println(" *************** CSV *****************");
            while(scanner.hasNext())
            {
                String[] data = scanner.nextLine().split(",");

                String cardNumber = data[0].trim();

                if(cardNumber.isEmpty() || cardNumber.equals(" "))
                {
                    list2.add(new CreditCard_(cardNumber,"Invalid: empty/null card number"));
                }
                else if(cardNumber.charAt(0) == '5' && cardNumber.length() == 16)
                {
                    MasterCC MasterCC = new MasterCC(data[0],data[1],data[2]);
                    list2.add(new CreditCard_(MasterCC.getCardNumber(),"MasterCard"));
                   // list.add(visaCC);
                }
                else if((cardNumber.charAt(0) == '4') && (cardNumber.length() == 16 || cardNumber.length() == 13))
                {
                    VisaCC visaCC = new VisaCC(data[0],data[1],data[2]);
                    list2.add(new CreditCard_(visaCC.getCardNumber(),"VISA"));
                    // list.add(visaCC);
                }
                else if((cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '4' && cardNumber.charAt(2) == '7') ||
                        (cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '7' && cardNumber.charAt(2) == '7')
                                && (cardNumber.length() == 15))
                {
                    AmericanExpress americanExpress = new AmericanExpress(data[0],data[1],data[2]);
                    list2.add(new CreditCard_(americanExpress.getCardNumber(),"AmericanExpress"));
                    // list.add(visaCC);
                }
                else if(isNumberic(cardNumber) == false)
                {
                    list2.add(new CreditCard_(cardNumber,"Invalid: non numeric characters"));
                }
                else if((cardNumber.charAt(0) == '6' && cardNumber.charAt(1) == '0' && cardNumber.charAt(2) == '1')
                        && cardNumber.charAt(3) == '1' && cardNumber.charAt(4) == '1'
                        && (cardNumber.length() == 16))
                {
                    Discover Discover = new Discover(data[0],data[1],data[2]);
                    list2.add(new CreditCard_(Discover.getCardNumber(),"Discover"));
                    // list.add(visaCC);
                }
                else if(cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '6' && cardNumber.charAt(2) == '0')
                {
                    list2.add(new CreditCard_(cardNumber,"Invalid: not a possible card number"));
                }

                else if(cardNumber.length() > CardLength)
                {
                    CreditCard creditCard = new CreditCard(data[0],data[1],data[2]);
                    list2.add(new CreditCard_(creditCard.getCardNumber(),"Invalid: more than 19 digits"));
                    // list.add(visaCC);
                }



                list.add(new CreditCard(data[0],data[1],data[2]));

            }


        }catch (Exception exception)
        {
            exception.printStackTrace();
        }

        view.display(list);
        saveFileData(list2);

        return list;
    }

    //to read json file - couldn't parse becuase file has issues - checked online through validator
    //ref : https://jsonlint.com
    // I have fixes json and now it's working
    public List<CreditCard> readJSONLFile(String path)
    {
        List<CreditCard> list = new ArrayList<CreditCard>();
        List<CreditCard_> list2 = new ArrayList<>();

        try {

            Object obj = new JSONParser().parse(new FileReader(path));
            JSONArray array = (JSONArray)obj;
            System.out.println(" *************** JSON *****************");
            for ( int i =0; i< array.size(); i++) {

                JSONObject jsonObject = (JSONObject) array.get(i);
                String cardNum = (String) jsonObject.get("cardNumber");
                String expirationDate = (String) jsonObject.get("expirationDate");
                String cardHolderName = (String) jsonObject.get("cardHolderName");

                String cardNumber = cardNum.trim();

                if(cardNumber.isEmpty() || cardNumber.equals(" "))
                {
                    list2.add(new CreditCard_(cardNumber,"Invalid: empty/null card number"));
                }
                else if(cardNumber.charAt(0) == '5' && cardNumber.length() == 16)
                {
                    MasterCC MasterCC = new MasterCC(cardNum,expirationDate,cardHolderName);
                    list2.add(new CreditCard_(MasterCC.getCardNumber(),"MasterCard"));
                    // list.add(visaCC);
                }
                else if((cardNumber.charAt(0) == '4') && (cardNumber.length() == 16 || cardNumber.length() == 13))
                {
                    VisaCC visaCC = new VisaCC(cardNum,expirationDate,cardHolderName);
                    list2.add(new CreditCard_(visaCC.getCardNumber(),"VISA"));
                    // list.add(visaCC);
                }
                else if((cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '4' && cardNumber.charAt(2) == '7') ||
                        (cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '7' && cardNumber.charAt(2) == '7')
                                && (cardNumber.length() == 15))
                {
                    AmericanExpress americanExpress = new AmericanExpress(cardNum,expirationDate,cardHolderName);
                    list2.add(new CreditCard_(americanExpress.getCardNumber(),"AmericanExpress"));
                    // list.add(visaCC);
                }
                else if(isNumberic(cardNumber) == false)
                {
                    list2.add(new CreditCard_(cardNumber,"Invalid: non numeric characters"));
                }
                else if((cardNumber.charAt(0) == '6' && cardNumber.charAt(1) == '0' && cardNumber.charAt(2) == '1')
                        && cardNumber.charAt(3) == '1' && cardNumber.charAt(4) == '1'
                        && (cardNumber.length() == 16))
                {
                    Discover Discover = new Discover(cardNum,expirationDate,cardHolderName);
                    list2.add(new CreditCard_(Discover.getCardNumber(),"Discover"));
                    // list.add(visaCC);
                }
                else if(cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '6' && cardNumber.charAt(2) == '0')
                {
                    list2.add(new CreditCard_(cardNumber,"Invalid: not a possible card number"));
                }

                else if(cardNumber.length() > CardLength)
                {
                    CreditCard creditCard = new CreditCard(cardNum,expirationDate,cardHolderName);
                    list2.add(new CreditCard_(creditCard.getCardNumber(),"Invalid: more than 19 digits"));
                    // list.add(visaCC);
                }

                list.add(new CreditCard(cardNum,expirationDate,cardHolderName));

            }


        } catch(Exception e) {
            e.printStackTrace();
        }

        view.display(list);
        saveJSONFile(list2);
        System.out.println(" *************** END-JSON *****************");

       return list;
    }

    //to read xml
    public List<CreditCard> readXMLFileData(String path)
    {
    	 List<CreditCard> list = new ArrayList<CreditCard>();
         List<CreditCard_> list2 = new ArrayList<CreditCard_>();

    	 try
    	 {
             File xmlFile = new File(path);
             DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
             DocumentBuilder builder = factory.newDocumentBuilder();
             Document doc = builder.parse(xmlFile);
             doc.getDocumentElement(); // root;
             NodeList cardNodes = doc.getElementsByTagName("CARD");
             System.out.println(" *************** XML *****************");
             for(int i=0; i<cardNodes.getLength(); i++)
             {
                 Node nodes = cardNodes.item(i);
                 Element cardElement = (Element) nodes;
                 String CARD_NUMBER = cardElement.getElementsByTagName("CARD_NUMBER").item(0).getTextContent();
                 String EXPIRATION_DATE = cardElement.getElementsByTagName("EXPIRATION_DATE").item(0).getTextContent();
                 String CARD_HOLDER_NAME = cardElement.getElementsByTagName("CARD_HOLDER_NAME").item(0).getTextContent();
                 System.out.println(CARD_NUMBER + " " +EXPIRATION_DATE + " " + CARD_HOLDER_NAME);

                 String cardNumber = CARD_NUMBER.trim();

                 if(cardNumber.isEmpty() || cardNumber.equals(" "))
                 {
                     list2.add(new CreditCard_(cardNumber,"Invalid: empty/null card number"));
                 }
                 else if(cardNumber.charAt(0) == '5' && cardNumber.length() == 16)
                 {
                     MasterCC MasterCC = new MasterCC(CARD_NUMBER,EXPIRATION_DATE,CARD_HOLDER_NAME);
                     list2.add(new CreditCard_(MasterCC.getCardNumber(),"MasterCard"));
                     // list.add(visaCC);
                 }
                 else if((cardNumber.charAt(0) == '4') && (cardNumber.length() == 16 || cardNumber.length() == 13))
                 {
                     VisaCC visaCC = new VisaCC(CARD_NUMBER,EXPIRATION_DATE,CARD_HOLDER_NAME);
                     list2.add(new CreditCard_(visaCC.getCardNumber(),"VISA"));
                     // list.add(visaCC);
                 }
                 else if((cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '4' && cardNumber.charAt(2) == '7') ||
                         (cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '7' && cardNumber.charAt(2) == '7')
                                 && (cardNumber.length() == 15))
                 {
                     AmericanExpress americanExpress = new AmericanExpress(CARD_NUMBER,EXPIRATION_DATE,CARD_HOLDER_NAME);
                     list2.add(new CreditCard_(americanExpress.getCardNumber(),"AmericanExpress"));
                     // list.add(visaCC);
                 }
                 else if(isNumberic(cardNumber) == false)
                 {
                     list2.add(new CreditCard_(cardNumber,"Invalid: non numeric characters"));
                 }
                 else if((cardNumber.charAt(0) == '6' && cardNumber.charAt(1) == '0' && cardNumber.charAt(2) == '1')
                         && cardNumber.charAt(3) == '1' && cardNumber.charAt(4) == '1'
                         && (cardNumber.length() == 16))
                 {
                     Discover Discover = new Discover(CARD_NUMBER,EXPIRATION_DATE,CARD_HOLDER_NAME);
                     list2.add(new CreditCard_(Discover.getCardNumber(),"Discover"));
                     // list.add(visaCC);
                 }
                 else if(cardNumber.charAt(0) == '3' && cardNumber.charAt(1) == '6' && cardNumber.charAt(2) == '0')
                 {
                     list2.add(new CreditCard_(cardNumber,"Invalid: not a possible card number"));
                 }

                 else if(cardNumber.length() > CardLength)
                 {
                     CreditCard creditCard = new CreditCard(CARD_NUMBER,EXPIRATION_DATE,CARD_HOLDER_NAME);
                     list2.add(new CreditCard_(creditCard.getCardNumber(),"Invalid: more than 19 digits"));
                     // list.add(visaCC);
                 }

                 list.add(new CreditCard(CARD_NUMBER,EXPIRATION_DATE,CARD_HOLDER_NAME));
             }
             System.out.println(" ********************************");
             saveXMLFileData(list2);

    	 }
    	 catch (Exception e)
    	 {
    	 e.printStackTrace();
    	 }

    	 return list;
    }


    //to save csv file
    public void saveXMLFileData(List<CreditCard_> list)
    {
        try{
            FileWriter fileWriter = new FileWriter(new File("output.xml"));
            fileWriter.write("<CARDS>\n");
            for (CreditCard_ c:list) {
                fileWriter.append(" <CARD>\n");
                fileWriter.append("     <CARD_NUMBER>" + c.getCardNumber() +"</CARD_NUMBER>\n");
                fileWriter.append("     <CARD_TYPE>" + c.getCardType() +"</CARD_TYPE>\n");
                fileWriter.append(" </CARD>\n");
            }
            fileWriter.append("</CARDS>\n");
            fileWriter.close();
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }

    }

    public void saveFileData(List<CreditCard_> list)
    {

        try{
            FileWriter fileWriter = new FileWriter(new File("output.csv"));
            fileWriter.write("cardNumber,cardType\n");
            for (CreditCard_ c:list) {
                if(!(c.getCardNumber().equalsIgnoreCase("cardnumber") &&
                        c.getCardType().equalsIgnoreCase("Invalid: non numeric characters")))
                    fileWriter.append(c.getCardNumber()+","+c.getCardType()+"\n");
            }
            fileWriter.close();
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }

    //to save csv file 
    public void saveJSONFile(List<CreditCard_> list)
    {
        try{
            FileWriter fileWriter = new FileWriter(new File("output.json"));
            fileWriter.write("[\n");
            for (int i = 0; i<list.size(); i++) {

                JSONObject obj = new JSONObject();

                obj.put("cardNumber",list.get(i).getCardNumber());
                obj.put("cardType",list.get(i).getCardType());

                StringWriter out = new StringWriter();
                obj.writeJSONString(out);

                String jsonText = out.toString();
                if(i == list.size()-1)
                {
                    fileWriter.append(jsonText+"\n");
                }
                else
                {
                    fileWriter.append(jsonText+",\n");
                }

            }
            fileWriter.write("\n]");
            fileWriter.close();
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }

    }

}
