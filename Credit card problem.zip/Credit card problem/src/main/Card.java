package main;

//for strategy design pattern
public interface Card {

     String getCardNumber();
     String getExpirationDate();
     String getCardHolderName();
}
