package main;

import model.CreditCard;
import java.util.List;

public class View {

    //to display
    public static void display(List<CreditCard> list)
    {
        for (CreditCard model: list) {
            System.out.println(model.getCardNumber() + "," + model.getExpirationDate() + "," + model.getCardHolderName());
        }

    }


}
