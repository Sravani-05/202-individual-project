package model;

public class MasterCC extends CreditCard{

    int cardLength = 16;
    private String firstFourDigit = "5";


    public MasterCC(String cardNumber, String expirationDate, String cardHolderName) {
        super(cardNumber, expirationDate, cardHolderName);
    }

    public String getFirstFourDigit() {
        return firstFourDigit;
    }

}
