package model;

public class VisaCC extends CreditCard{

    int cardLength1 = 13;
    int cardLength2 = 16;
    private String firstFourDigit = "5";

    public VisaCC(String cardNumber, String expirationDate, String cardHolderName) {
        super(cardNumber, expirationDate, cardHolderName);
    }

    public String getFirstFourDigit() {
        return firstFourDigit;
    }

    public int getCardLength1() {
        return cardLength1;
    }

    public int getCardLength2() {
        return cardLength2;
    }
}
