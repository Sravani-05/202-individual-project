package model;

public class AmericanExpress extends CreditCard{

    final int CardLength = 15; // 19 digit
    private String firstFourDigt1 = "34";
    private String firstFourDigt2 = "37";

    public AmericanExpress(String cardNumber, String expirationDate, String cardHolderName) {
        super(cardNumber, expirationDate, cardHolderName);
    }


}
