package model;

import main.Card;

public class CreditCard implements Card {

    //attributes
    protected String cardNumber,expirationDate,cardHolderName;

    //constructor
    public CreditCard(String cardNumber, String expirationDate, String cardHolderName) {
        this.cardNumber = cardNumber;
        this.expirationDate = expirationDate;
        this.cardHolderName = cardHolderName;
    }

    //getter and setters

    @Override
    public String getCardNumber() {
        return cardNumber;
    }

    @Override
    public String getExpirationDate() {
        return expirationDate;
    }

    @Override
    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

}
