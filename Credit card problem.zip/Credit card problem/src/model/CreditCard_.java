package model;

public class CreditCard_ {

    private String cardNumber, cardType;

    public CreditCard_(String cardNumber, String cardType) {
        this.cardNumber = cardNumber;
        this.cardType = cardType;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getCardType() {
        return cardType;
    }
}
