package model;

public class Discover extends CreditCard{

    int cardLength = 16;
    private String firstFourDigt = "6011";

    public Discover(String cardNumber, String expirationDate, String cardHolderName) {
        super(cardNumber, expirationDate, cardHolderName);
    }

}
